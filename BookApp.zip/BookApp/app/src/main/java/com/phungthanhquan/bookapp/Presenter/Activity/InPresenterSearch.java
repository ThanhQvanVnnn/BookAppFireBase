package com.phungthanhquan.bookapp.Presenter.Activity;

public interface InPresenterSearch {
    void xuliTimKiem(String kitu);
}
