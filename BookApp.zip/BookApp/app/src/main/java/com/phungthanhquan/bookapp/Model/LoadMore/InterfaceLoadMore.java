package com.phungthanhquan.bookapp.Model.LoadMore;

import android.widget.ProgressBar;

import com.phungthanhquan.bookapp.Object.ItemBook;

import java.util.List;

public interface InterfaceLoadMore {
    void hienThiLoadMore(int tongItem);
}
