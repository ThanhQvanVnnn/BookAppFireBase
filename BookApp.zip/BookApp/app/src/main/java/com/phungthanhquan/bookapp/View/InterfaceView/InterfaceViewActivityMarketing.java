package com.phungthanhquan.bookapp.View.InterfaceView;

import com.phungthanhquan.bookapp.Object.ItemBook;

import java.util.List;

public interface InterfaceViewActivityMarketing {
    void hienThidulieu(List<ItemBook> itemBookList);
}
