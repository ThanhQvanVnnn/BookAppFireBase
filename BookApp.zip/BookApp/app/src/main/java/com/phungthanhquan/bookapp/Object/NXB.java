package com.phungthanhquan.bookapp.Object;

public class NXB {

    private String imageNXB;
    private String tenNXB;

    public NXB(String imageNXB, String tenNXB) {
        this.imageNXB = imageNXB;
        this.tenNXB = tenNXB;
    }

    public String getImageNXB() {
        return imageNXB;
    }

    public void setImageNXB(String imageNXB) {
        this.imageNXB = imageNXB;
    }

    public String getTenNXB() {
        return tenNXB;
    }

    public void setTenNXB(String tenNXB) {
        this.tenNXB = tenNXB;
    }
}
