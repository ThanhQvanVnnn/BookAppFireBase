package com.phungthanhquan.bookapp.View.InterfaceView;

import com.phungthanhquan.bookapp.Object.User;

import java.util.List;

public interface InterfaceViewFragmentCaNhan {
    void hienThiThongTinCaNhan(User user);
}
