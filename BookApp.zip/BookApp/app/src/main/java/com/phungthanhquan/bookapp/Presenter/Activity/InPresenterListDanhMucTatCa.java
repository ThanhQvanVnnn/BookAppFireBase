package com.phungthanhquan.bookapp.Presenter.Activity;

public interface InPresenterListDanhMucTatCa {
    void xuliHienThiChiTietDanhMuc();
}
