package com.phungthanhquan.bookapp.Presenter.Fragment;

public interface PresenterInterfaceCaNhan {
    void hienThiThongTinCaNhan();
}
