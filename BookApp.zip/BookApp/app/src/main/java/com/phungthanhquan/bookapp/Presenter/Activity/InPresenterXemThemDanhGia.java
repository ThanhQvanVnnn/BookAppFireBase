package com.phungthanhquan.bookapp.Presenter.Activity;

public interface InPresenterXemThemDanhGia {
    void xuliHienThi();
}
