package com.phungthanhquan.bookapp.Presenter.Activity;

public interface InPresenterListBookToChoice {
    void hienThiDanhSach();
}
