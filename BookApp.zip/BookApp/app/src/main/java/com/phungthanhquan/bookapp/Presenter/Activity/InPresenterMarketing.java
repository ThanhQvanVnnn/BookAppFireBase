package com.phungthanhquan.bookapp.Presenter.Activity;

public interface InPresenterMarketing {
    void xuliHienThiChiTietMarketing();
}
