package com.phungthanhquan.bookapp.Presenter.Fragment;

public interface PresenterInterfaceDanhMuc {
    void xuliHienThiDanhMuc();
}
