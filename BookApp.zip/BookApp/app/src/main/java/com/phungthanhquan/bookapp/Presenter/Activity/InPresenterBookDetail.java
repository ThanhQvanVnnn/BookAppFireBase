package com.phungthanhquan.bookapp.Presenter.Activity;

public interface InPresenterBookDetail {
    void xuliHienThiSach();
    void xuliHienThiDsDanhGia();
}
