package com.phungthanhquan.bookapp.View.InterfaceView;

import com.phungthanhquan.bookapp.Object.BinhLuan;
import com.phungthanhquan.bookapp.Object.Book;

import java.util.List;

public interface InterfaceViewActivityDetailBook {
    void hienThiNoiDungSach(Book book);
    void hienThiDsDanhGia(List<BinhLuan> dsDanhGia);
}
