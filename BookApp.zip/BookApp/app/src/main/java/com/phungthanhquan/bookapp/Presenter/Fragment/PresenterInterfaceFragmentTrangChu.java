package com.phungthanhquan.bookapp.Presenter.Fragment;

public interface PresenterInterfaceFragmentTrangChu {
    void xulislider();
    void xuliHienthiDsSachMoi();
    void xuliHienthiDsSachKhuyenDoc();
    void xuliHienthiDsSachVanHocTrongNuoc();
    void xuliHienThiDsNhaXuatBan();
    void xuliHienThiAlBumSach();
}
