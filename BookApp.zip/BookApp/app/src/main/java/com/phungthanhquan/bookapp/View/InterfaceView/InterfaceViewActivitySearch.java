package com.phungthanhquan.bookapp.View.InterfaceView;

import com.phungthanhquan.bookapp.Object.ItemBook;

import java.util.List;

public interface InterfaceViewActivitySearch {
    void timkiemsachthanhcong(List<ItemBook> dsSachs);
    void timkiemsachthatbai();
}
