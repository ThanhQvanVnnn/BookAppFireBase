package com.phungthanhquan.bookapp.View.InterfaceView;

import com.phungthanhquan.bookapp.Object.DanhMuc;

import java.util.List;

public interface InterfaceViewFragmentDanhMuc {
    void hienThiDanhMuc(List<DanhMuc> danhMucList);
}
