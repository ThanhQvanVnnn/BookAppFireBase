package com.phungthanhquan.bookapp.View.InterfaceView;

import com.phungthanhquan.bookapp.Object.BinhLuan;

import java.util.List;

public interface InterfaceViewActivityDanhSachDanhGia {
    void hienThiDanhSach(List<BinhLuan> binhLuanList);
}
