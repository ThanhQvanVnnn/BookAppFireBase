package com.phungthanhquan.bookapp.View.InterfaceView;

import com.phungthanhquan.bookapp.Object.ItemBookCase;

import java.util.List;

public interface InterfaceViewFragmentTuSach {
    void hienthiDsSach(List<ItemBookCase> itemBookCases);
}
