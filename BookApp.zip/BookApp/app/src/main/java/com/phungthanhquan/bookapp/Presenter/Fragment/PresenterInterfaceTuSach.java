package com.phungthanhquan.bookapp.Presenter.Fragment;

public interface PresenterInterfaceTuSach {
    void xulihienthiDSCuaTuSach();
}
