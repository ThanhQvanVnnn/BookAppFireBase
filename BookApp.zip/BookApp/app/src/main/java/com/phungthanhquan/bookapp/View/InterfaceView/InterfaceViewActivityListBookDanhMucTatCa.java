package com.phungthanhquan.bookapp.View.InterfaceView;

import com.phungthanhquan.bookapp.Object.ItemBook;

import java.util.List;

public interface InterfaceViewActivityListBookDanhMucTatCa {
    void hienthiDanhSachChitiet(List<ItemBook> itemBooks);
}
